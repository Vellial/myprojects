/**
 * Writer implementation.
 */
package com.lightside.codeformatterproject.writer.writerimpl;