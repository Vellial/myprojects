/**
 * Reader interface
 */
package com.lightside.codeformatterproject.reader;