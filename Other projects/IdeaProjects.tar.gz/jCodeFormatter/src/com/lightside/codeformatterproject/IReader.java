package com.lightside.codeformatterproject;

/**
 * Created by vellial on 21.04.16.
 */
public interface IReader {
    char read();
    void close();
}
