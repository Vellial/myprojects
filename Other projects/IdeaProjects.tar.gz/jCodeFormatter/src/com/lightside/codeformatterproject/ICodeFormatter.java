package com.lightside.codeformatterproject;

/**
 * Created by vellial on 21.04.16.
 */
public interface ICodeFormatter {
    void formatCode(IReader reader, IWriter writer);
}
