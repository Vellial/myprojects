/**
 * Package for settings.
 */
package com.lightside.codeformatterproject.settings;