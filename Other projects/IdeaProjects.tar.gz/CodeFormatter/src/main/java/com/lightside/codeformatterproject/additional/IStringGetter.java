package com.lightside.codeformatterproject.additional;

/**
 * Getter string.
 */
public interface IStringGetter {
    /**
     * Method for getting string.
     * @return string.
     */
    String getString();
}
