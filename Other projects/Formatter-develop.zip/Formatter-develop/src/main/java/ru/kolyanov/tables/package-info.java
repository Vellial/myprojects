/**
 * this package contain tables fo formatting
 */

package ru.kolyanov.tables;