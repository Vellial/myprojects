package com.lightside.codeformatterproject;

/**
 * Created by vellial on 21.04.16.
 */
public interface IWriter {
    void write(String str);
    void close();
}
