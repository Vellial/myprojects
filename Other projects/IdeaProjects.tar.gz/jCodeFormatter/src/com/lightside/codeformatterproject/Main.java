package com.lightside.codeformatterproject;

public class Main {

    public static void main(String[] args) {
        String code = "while(x<3){int i = 0; i=i+x; System.out.println(i);}";

	// write your code here
    }
}
