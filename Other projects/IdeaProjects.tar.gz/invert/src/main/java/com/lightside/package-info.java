/**
 * This package contains all projects.
 */
package com.lightside;