/**
 * Code formatter interface
 */
package com.lightside.codeformatterproject.codeformatter;