/**
 * Reader implementation.
 */
package com.lightside.codeformatterproject.reader.readerimpl;