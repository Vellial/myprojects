package com.lightside.codeformatterproject.additional;

/**
 * Closable interface.
 */
public interface IClosable extends AutoCloseable {

}
