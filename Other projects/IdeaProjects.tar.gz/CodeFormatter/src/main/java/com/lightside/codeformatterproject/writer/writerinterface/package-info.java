/**
 * Writer interface.
 */
package com.lightside.codeformatterproject.writer.writerinterface;