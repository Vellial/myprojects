/**
 * this package contain classes and interfaces for reading data
 */

package ru.kolyanov.input;