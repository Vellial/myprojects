/**
 * This package contains class for inverting integer arrays.
 */
package com.lightside.invertproject.inverter;