/**
 * this package contain classes and interfaces for writing formatted data
 */

package ru.kolyanov.output;