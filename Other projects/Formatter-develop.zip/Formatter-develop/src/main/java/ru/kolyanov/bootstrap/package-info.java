/**
 * this package contain bootstrap class only
 */

package ru.kolyanov.bootstrap;