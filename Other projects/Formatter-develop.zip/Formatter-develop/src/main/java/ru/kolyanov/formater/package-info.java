/**
 * this package contain classes for formater data from input package
 */

package ru.kolyanov.formater;